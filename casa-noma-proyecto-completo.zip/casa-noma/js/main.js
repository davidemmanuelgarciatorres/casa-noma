/* CASA NOMA | Etapa 2: menú móvil */
(function () {
  "use strict";
  var toggle = document.querySelector(".nav-toggle");
  var nav = document.getElementById("menu-principal");
  if (!toggle || !nav) return;

  function setOpen(open) {
    toggle.setAttribute("aria-expanded", String(open));
    nav.classList.toggle("open", open);
  }

  toggle.addEventListener("click", function () {
    setOpen(toggle.getAttribute("aria-expanded") !== "true");
  });

  nav.addEventListener("click", function (e) {
    if (e.target.closest("a")) setOpen(false);
  });

  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape" && toggle.getAttribute("aria-expanded") === "true") {
      setOpen(false);
      toggle.focus();
    }
  });
})();

/* ===== Etapa 3: menú por pestañas, galería, formularios de demostración ===== */
(function () {
  "use strict";

  // Pestañas del menú
  var tabs = Array.prototype.slice.call(document.querySelectorAll(".tab"));
  function show(tab, focus) {
    tabs.forEach(function (t) {
      var on = t === tab;
      t.setAttribute("aria-selected", String(on));
      t.tabIndex = on ? 0 : -1;
      document.getElementById(t.getAttribute("aria-controls")).hidden = !on;
    });
    if (focus) tab.focus();
  }
  if (tabs.length) {
    show(tabs[0]);
    tabs.forEach(function (t, i) {
      t.addEventListener("click", function () { show(t); });
      t.addEventListener("keydown", function (e) {
        var n = e.key === "ArrowRight" ? i + 1 : e.key === "ArrowLeft" ? i - 1 : e.key === "Home" ? 0 : e.key === "End" ? tabs.length - 1 : null;
        if (n === null) return;
        e.preventDefault();
        show(tabs[(n + tabs.length) % tabs.length], true);
      });
    });
  }

  // Visor de imágenes
  var viewer = document.querySelector(".viewer");
  if (viewer && viewer.showModal) {
    var big = viewer.querySelector("img");
    document.querySelectorAll(".g-open").forEach(function (b) {
      b.addEventListener("click", function () {
        big.src = b.dataset.full;
        big.alt = b.dataset.alt;
        viewer.showModal();
      });
    });
    viewer.querySelector(".viewer-close").addEventListener("click", function () { viewer.close(); });
    viewer.addEventListener("click", function (e) { if (e.target === viewer) viewer.close(); });
  }

  // Fecha mínima: hoy
  var d = new Date();
  var hoy = d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
  document.querySelectorAll("input[data-future]").forEach(function (i) { i.min = hoy; });

  // Formularios de demostración: validan, simulan carga y no envían nada
  function error(f) {
    var v = f.value.trim();
    if (f.required && !v) return f.tagName === "SELECT" ? "Elige una opción." : "Completa este campo.";
    if (f.type === "email" && v && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) return "Escribe un correo válido, por ejemplo nombre@correo.com.";
    if (f.hasAttribute("data-future") && v && v < hoy) return "Elige una fecha de hoy en adelante.";
    return "";
  }
  function check(f) {
    var msg = error(f);
    var out = document.getElementById("e-" + f.id);
    if (out) out.textContent = msg;
    f.setAttribute("aria-invalid", msg ? "true" : "false");
    return !msg;
  }
  document.querySelectorAll("[data-demo-form]").forEach(function (form) {
    var fields = Array.prototype.slice.call(form.querySelectorAll("input, select, textarea"));
    var btn = form.querySelector("button[type=submit]");
    var status = form.querySelector(".status");
    // Los errores se muestran al enviar y se corrigen mientras se escribe; nunca al salir
    // del campo, porque el salto de diseño haría fallar el toque sobre el botón.
    fields.forEach(function (f) {
      ["input", "change"].forEach(function (ev) {
        f.addEventListener(ev, function () { if (f.getAttribute("aria-invalid") === "true") check(f); });
      });
    });
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      status.textContent = "";
      var bad = fields.filter(function (f) { return !check(f); });
      if (bad.length) { bad[0].focus(); return; }
      var label = btn.textContent;
      btn.disabled = true;
      btn.textContent = "Procesando…";
      setTimeout(function () {
        form.reset();
        btn.disabled = false;
        btn.textContent = label;
        status.textContent = form.dataset.done;
      }, 1100);
    });
  });
})();

/* ===== Etapa 4: el menú móvil se cierra al tocar fuera o al pasar a pantalla grande ===== */
(function () {
  "use strict";
  var t = document.querySelector(".nav-toggle");
  var n = document.getElementById("menu-principal");
  if (!t || !n) return;
  function close() { t.setAttribute("aria-expanded", "false"); n.classList.remove("open"); }
  document.addEventListener("click", function (e) {
    if (n.classList.contains("open") && !e.target.closest(".site-header")) close();
  });
  if (window.matchMedia) {
    var mq = window.matchMedia("(min-width: 900px)");
    var onChange = function (e) { if (e.matches) close(); };
    if (mq.addEventListener) mq.addEventListener("change", onChange);
  }
})();
